import React, { useState, useEffect, useMemo } from 'react';
import {
  Search,
  QrCode,
  Plus,
  Edit2,
  Trash2,
  Printer,
  ShoppingBag,
  Store,
  ChevronRight,
  TrendingUp,
  Package,
  Layers,
  Settings,
  Clock,
  Sparkles,
  DownloadCloud,
  FileSpreadsheet,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import { Product, CartItem, Transaction, StoreSettings } from './types';
import { INITIAL_PRODUCTS, INITIAL_SETTINGS, formatRp, formatDate } from './utils/constants';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { PWAInstallModal } from './components/PWAInstallModal';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { CartModal } from './components/CartModal';
import { ProductModal } from './components/ProductModal';
import { SettingsModal } from './components/SettingsModal';
import { ReceiptPrintTemplate } from './components/ReceiptPrintTemplate';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ConfirmModal } from './components/ConfirmModal';
import { Toast, ToastMessage } from './components/Toast';
import { usePWAInstall } from './hooks/usePWAInstall';

export default function App() {
  // Navigation tab state
  const [activeTab, setActiveTab] = useState<'cashier' | 'products' | 'reports'>('cashier');

  // Core Data States with LocalStorage
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('pos_products_kdm');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // If stored products don't have images yet, backfill from initial presets
          return parsed.map((p: Product) => {
            if (!p.image) {
              const matched = INITIAL_PRODUCTS.find(
                (init) => init.id === p.id || init.name.toLowerCase() === p.name.toLowerCase()
              );
              if (matched?.image) {
                return { ...p, image: matched.image };
              }
            }
            return p;
          });
        }
      }
    } catch (e) {
      console.error('Failed to load products from storage:', e);
    }
    return INITIAL_PRODUCTS;
  });

  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('pos_trx_kdm');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch (e) {
      console.error('Failed to load transactions from storage:', e);
    }
    return [];
  });

  const [settings, setSettings] = useState<StoreSettings>(() => {
    try {
      const saved = localStorage.getItem('pos_settings_kdm');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.storeName) return parsed;
      }
    } catch (e) {
      console.error('Failed to load settings from storage:', e);
    }
    return INITIAL_SETTINGS;
  });

  // Cart State
  const [cart, setCart] = useState<CartItem[]>([]);

  // Search & Filter States
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [reportFilter, setReportFilter] = useState<'today' | 'yesterday' | 'week' | 'all'>('today');

  // Modals & Scanner state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannerTarget, setScannerTarget] = useState<'cashier' | 'product'>('cashier');
  const [isCartModalOpen, setIsCartModalOpen] = useState(false);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productToEdit, setProductToEdit] = useState<Product | null>(null);
  const [scannedBarcodeForProduct, setScannedBarcodeForProduct] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Active Transaction for printing / reprinting
  const [printTransaction, setPrintTransaction] = useState<Transaction | null>(null);

  // In-app confirmation dialog state (replaces window.confirm)
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel?: string;
    cancelLabel?: string;
    isDestructive?: boolean;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // In-app toast feedback state (replaces window.alert)
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ id: Date.now().toString(), message, type });
  };

  // PWA Install hook
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // Save to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('pos_products_kdm', JSON.stringify(products));
    } catch (e) {
      console.warn('Gagal menyimpan produk ke localStorage:', e);
    }
  }, [products]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_trx_kdm', JSON.stringify(transactions));
    } catch (e) {
      console.warn('Gagal menyimpan transaksi ke localStorage:', e);
    }
  }, [transactions]);

  useEffect(() => {
    try {
      localStorage.setItem('pos_settings_kdm', JSON.stringify(settings));
    } catch (e) {
      console.warn('Gagal menyimpan setelan ke localStorage:', e);
    }
  }, [settings]);

  // Handle adding product to cart
  const handleAddToCart = (product: Product) => {
    if (product.stock <= 0) {
      showToast(`Stok "${product.name}" sedang habis!`, 'error');
      return;
    }

    setCart((prevCart) => {
      const existing = prevCart.find((i) => i.id === product.id);
      if (existing) {
        if (existing.qty >= product.stock) {
          showToast(`Batas stok maksimum tercapai (${product.stock} pcs)`, 'info');
          return prevCart;
        }
        showToast(`+1 ${product.name} di keranjang`, 'success');
        return prevCart.map((i) =>
          i.id === product.id ? { ...i, qty: i.qty + 1 } : i
        );
      } else {
        showToast(`${product.name} ditambahkan`, 'success');
        return [
          ...prevCart,
          {
            id: product.id,
            name: product.name,
            price: product.price,
            costPrice: product.costPrice,
            qty: 1,
            image: product.image,
          },
        ];
      }
    });
  };

  // Update cart item quantity
  const handleUpdateQty = (id: number, delta: number) => {
    const product = products.find((p) => p.id === id);
    setCart((prevCart) => {
      const item = prevCart.find((i) => i.id === id);
      if (!item) return prevCart;

      const newQty = item.qty + delta;
      if (newQty <= 0) {
        return prevCart.filter((i) => i.id !== id);
      }
      if (product && newQty > product.stock) {
        showToast(`Maksimal stok yang tersedia adalah ${product.stock}`, 'error');
        return prevCart;
      }
      return prevCart.map((i) => (i.id === id ? { ...i, qty: newQty } : i));
    });
  };

  const handleRemoveFromCart = (id: number) => {
    setCart((prev) => prev.filter((i) => i.id !== id));
  };

  const handleClearCart = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Kosongkan Keranjang?',
      message: 'Semua produk yang ada di dalam keranjang belanja akan dihapus.',
      confirmLabel: 'Ya, Kosongkan',
      cancelLabel: 'Batal',
      isDestructive: true,
      onConfirm: () => {
        setCart([]);
        showToast('Keranjang belanja berhasil dikosongkan', 'info');
      },
    });
  };

  // Process Checkout
  const handleCheckout = (
    paidAmount: number,
    paymentMethod: 'cash' | 'qris',
    shouldPrint: boolean
  ) => {
    const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
    const change = Math.max(0, paidAmount - total);

    // Deduct stock from products
    setProducts((prevProducts) =>
      prevProducts.map((p) => {
        const cartItem = cart.find((c) => c.id === p.id);
        if (cartItem) {
          return { ...p, stock: Math.max(0, p.stock - cartItem.qty) };
        }
        return p;
      })
    );

    const now = new Date();
    const newTransaction: Transaction = {
      id: Date.now(),
      date: formatDate(now),
      timestamp: now.getTime(),
      total,
      paid: paidAmount,
      change,
      paymentMethod,
      items: [...cart],
    };

    setTransactions((prev) => [newTransaction, ...prev]);
    setCart([]);
    setIsCartModalOpen(false);
    showToast('Transaksi berhasil disimpan!', 'success');

    if (shouldPrint) {
      setPrintTransaction(newTransaction);
      setTimeout(() => {
        window.print();
      }, 300);
    }
  };

  // Reprint previous transaction receipt
  const handleReprint = (tx: Transaction) => {
    setPrintTransaction(tx);
    setTimeout(() => {
      window.print();
    }, 200);
  };

  // Save product (Add or Edit)
  const handleSaveProduct = (productData: Omit<Product, 'id'>, id?: number) => {
    if (id) {
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...productData, id } : p))
      );
      showToast(`Produk "${productData.name}" berhasil diperbarui`, 'success');
    } else {
      setProducts((prev) => [
        { ...productData, id: Date.now() },
        ...prev,
      ]);
      showToast(`Produk "${productData.name}" berhasil ditambahkan`, 'success');
    }
  };

  // Delete product with in-app confirmation dialog
  const handleDeleteProduct = (id: number) => {
    const product = products.find((p) => p.id === id);
    if (!product) return;

    setConfirmModal({
      isOpen: true,
      title: 'Hapus Produk?',
      message: `Apakah Anda yakin ingin menghapus "${product.name}" dari katalog warung? Tindakan ini tidak dapat dibatalkan.`,
      confirmLabel: 'Hapus Produk',
      cancelLabel: 'Batal',
      isDestructive: true,
      onConfirm: () => {
        setProducts((prev) => prev.filter((p) => p.id !== id));
        setCart((prev) => prev.filter((c) => c.id !== id));
        showToast(`Produk "${product.name}" berhasil dihapus`, 'success');
      },
    });
  };

  // Quick adjust stock in product management
  const handleQuickAddStock = (id: number, amount: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, stock: p.stock + amount } : p))
    );
  };

  // Handle scanned barcode from camera
  const handleScanSuccess = (code: string) => {
    if (scannerTarget === 'cashier') {
      setSearchQuery(code);
      // Auto add if exact match
      const matched = products.find((p) => p.barcode === code);
      if (matched) {
        handleAddToCart(matched);
      }
    } else {
      setScannedBarcodeForProduct(code);
    }
  };

  // Open Barcode scanner
  const openScanner = (target: 'cashier' | 'product') => {
    setScannerTarget(target);
    setIsScannerOpen(true);
  };

  // Export transactions to CSV
  const handleExportCSV = () => {
    if (transactions.length === 0) {
      showToast('Belum ada transaksi untuk diekspor!', 'info');
      return;
    }
    const headers = ['ID Transaksi', 'Tanggal', 'Total (Rp)', 'Dibayar (Rp)', 'Kembali (Rp)', 'Metode', 'Daftar Barang'];
    const rows = transactions.map((t) => [
      t.id,
      `"${t.date}"`,
      t.total,
      t.paid,
      t.change,
      t.paymentMethod.toUpperCase(),
      `"${t.items.map((i) => `${i.name} (${i.qty}x)`).join(', ')}"`,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `laporan-transaksi-warung-kdm-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Laporan transaksi berhasil diunduh', 'success');
  };

  // Filtered Products for Cashier
  const filteredProducts = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    return products.filter((p) => {
      const matchesSearch =
        p.name.toLowerCase().includes(q) || (p.barcode && p.barcode.toLowerCase().includes(q));
      const matchesCategory =
        selectedCategory === 'Semua' || p.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, searchQuery, selectedCategory]);

  // Categories list
  const categories = ['Semua', 'Sembako', 'Makanan', 'Minuman', 'Kebersihan', 'Lainnya'];

  // Filtered Transactions for Reports
  const filteredTransactions = useMemo(() => {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const startOfYesterday = startOfToday - 24 * 60 * 60 * 1000;
    const startOfWeek = startOfToday - 7 * 24 * 60 * 60 * 1000;

    return transactions.filter((t) => {
      if (reportFilter === 'today') return t.timestamp >= startOfToday;
      if (reportFilter === 'yesterday')
        return t.timestamp >= startOfYesterday && t.timestamp < startOfToday;
      if (reportFilter === 'week') return t.timestamp >= startOfWeek;
      return true;
    });
  }, [transactions, reportFilter]);

  // Financial calculations
  const reportTotals = useMemo(() => {
    let totalRevenue = 0;
    let totalCost = 0;

    filteredTransactions.forEach((t) => {
      totalRevenue += t.total;
      t.items.forEach((item) => {
        totalCost += (item.costPrice || 0) * item.qty;
      });
    });

    const profit = totalRevenue - totalCost;
    const profitMargin = totalRevenue > 0 ? ((profit / totalRevenue) * 100).toFixed(1) : '0';

    return {
      revenue: totalRevenue,
      cost: totalCost,
      profit,
      margin: profitMargin,
      count: filteredTransactions.length,
    };
  }, [filteredTransactions]);

  // Cart total quantities & amount
  const cartTotalQty = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotalPrice = cart.reduce((s, i) => s + i.price * i.qty, 0);

  return (
    <div className="flex flex-col min-h-screen bg-slate-100 text-slate-900 max-w-md mx-auto shadow-2xl relative select-none pb-20">
      {/* Top Android PWA Installation Banner */}
      <PWAInstallBanner />

      {/* App Header */}
      <header className="bg-gradient-to-r from-indigo-700 via-indigo-600 to-blue-600 text-white pt-4 pb-4 px-4 shadow-lg sticky top-0 z-30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-white/15 backdrop-blur-md border border-white/25 flex items-center justify-center p-1.5 shadow-inner">
              <img src="/icon.svg" alt="Warung KDM" className="w-full h-full object-contain" />
            </div>
            <div>
              <h1 className="font-extrabold text-lg tracking-wide leading-tight flex items-center gap-1.5">
                <span>{settings.storeName}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-400 text-slate-950 font-bold uppercase tracking-wider">
                  POS
                </span>
              </h1>
              <p className="text-[11px] text-indigo-100 font-medium">Kasir Pintar Siap Instal di Android</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Android Install Button in Header */}
            {!isInstalled && (
              <button
                onClick={async () => {
                  if (isInstallable) {
                    const ok = await install();
                    if (!ok) setIsInstallModalOpen(true);
                  } else {
                    setIsInstallModalOpen(true);
                  }
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-sm active:scale-95 transition"
                title="Pasang aplikasi di HP Android"
              >
                <DownloadCloud className="w-3.5 h-3.5" />
                <span>Instal</span>
              </button>
            )}

            {/* Settings button */}
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition active:scale-95"
              title="Pengaturan Warung"
            >
              <Settings className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Areas */}
      <main className="flex-1 p-3.5 overflow-y-auto">
        {/* ==================== TAB 1: KASIR ==================== */}
        {activeTab === 'cashier' && (
          <div className="space-y-3">
            {/* Search Bar & Barcode Scanner Button */}
            <div className="flex gap-2 items-center">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Cari produk / barcode..."
                  className="w-full py-2.5 pl-9 pr-8 bg-white border border-slate-200 rounded-2xl text-xs font-medium outline-none focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 shadow-sm transition"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
                  >
                    ✕
                  </button>
                )}
              </div>

              {/* Barcode Camera Scanner */}
              <button
                onClick={() => openScanner('cashier')}
                className="w-10 h-10 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white flex items-center justify-center shadow-md shadow-indigo-600/30 active:scale-95 transition shrink-0"
                title="Buka Scanner Barcode Kamera"
              >
                <QrCode className="w-5 h-5" />
              </button>
            </div>

            {/* Category Filter Pills */}
            <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-xl font-semibold whitespace-nowrap transition text-[11px] ${
                    selectedCategory === cat
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Product Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 px-4 bg-white rounded-3xl border border-slate-200 shadow-xs">
                <div className="w-14 h-14 mx-auto rounded-2xl bg-indigo-50 text-indigo-500 flex items-center justify-center mb-3">
                  <Package className="w-7 h-7" />
                </div>
                <h3 className="font-bold text-sm text-slate-800">Produk Tidak Ditemukan</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
                  Coba kata kunci lain atau tambahkan produk baru di tab "Produk".
                </p>
                <button
                  onClick={() => {
                    setProductToEdit(null);
                    setIsProductModalOpen(true);
                  }}
                  className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-semibold shadow-sm hover:bg-indigo-700 transition"
                >
                  + Tambah Produk Ini
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {filteredProducts.map((p) => {
                  const inCartItem = cart.find((c) => c.id === p.id);
                  const isOutOfStock = p.stock <= 0;

                  return (
                    <div
                      key={p.id}
                      onClick={() => !isOutOfStock && handleAddToCart(p)}
                      className={`relative p-2.5 rounded-2xl bg-white border transition flex flex-col justify-between shadow-xs overflow-hidden group ${
                        isOutOfStock
                          ? 'opacity-60 border-slate-200 cursor-not-allowed bg-slate-50'
                          : 'border-slate-200 hover:border-indigo-400 hover:shadow-md cursor-pointer active:scale-95'
                      }`}
                    >
                      {/* Product Image on Card */}
                      <div className="relative w-full aspect-[4/3] rounded-xl bg-slate-100 overflow-hidden mb-2 border border-slate-100 flex items-center justify-center">
                        {p.image ? (
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
                            loading="lazy"
                          />
                        ) : (
                          <div className="flex flex-col items-center justify-center text-slate-300">
                            <Package className="w-7 h-7 stroke-1 text-slate-400" />
                          </div>
                        )}

                        {/* Category Tag Overlay */}
                        <span className="absolute top-1.5 left-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-slate-900/75 text-white backdrop-blur-xs">
                          {p.category || 'Barang'}
                        </span>

                        {/* In-Cart badge indicator */}
                        {inCartItem && (
                          <div className="absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-indigo-600 text-white font-black text-[11px] flex items-center justify-center shadow-md border-2 border-white animate-in zoom-in-75">
                            {inCartItem.qty}
                          </div>
                        )}
                      </div>

                      <div className="px-0.5">
                        <h3 className="font-bold text-xs text-slate-900 leading-snug line-clamp-2 min-h-[32px]">
                          {p.name}
                        </h3>
                      </div>

                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-baseline justify-between px-0.5">
                        <span className="font-extrabold text-xs text-indigo-700">
                          {formatRp(p.price)}
                        </span>
                        <span
                          className={`text-[10px] font-medium px-1.5 py-0.5 rounded-md ${
                            isOutOfStock
                              ? 'bg-rose-100 text-rose-700 font-bold'
                              : p.stock <= 5
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {isOutOfStock ? 'Habis' : `Stok: ${p.stock}`}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB 2: PRODUK (INVENTORY) ==================== */}
        {activeTab === 'products' && (
          <div className="space-y-3">
            {/* Header Action: Add product & stock summary */}
            <div className="p-3.5 rounded-2xl bg-indigo-600 text-white shadow-md flex items-center justify-between">
              <div>
                <span className="text-xs text-indigo-200 font-medium">Total Produk</span>
                <div className="text-xl font-black">{products.length} Barang</div>
                <div className="text-[11px] text-indigo-100 mt-0.5">
                  Total Stok: {products.reduce((s, p) => s + p.stock, 0)} unit
                </div>
              </div>
              <button
                onClick={() => {
                  setProductToEdit(null);
                  setIsProductModalOpen(true);
                }}
                className="py-2.5 px-3.5 bg-white text-indigo-700 rounded-xl font-bold text-xs shadow-md hover:bg-indigo-50 active:scale-95 transition flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4 text-indigo-600" />
                <span>Tambah Produk</span>
              </button>
            </div>

            {/* Product List */}
            <div className="space-y-2">
              {products.length === 0 ? (
                <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-4">
                  <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">Belum Ada Data Produk</p>
                  <p className="text-xs text-slate-400 mt-1">Tambahkan produk pertama untuk mulai berjualan.</p>
                </div>
              ) : (
                products.map((p) => {
                  const estProfit = p.price - (p.costPrice || 0);

                  return (
                    <div
                      key={p.id}
                      className="p-3 bg-white rounded-2xl border border-slate-200 shadow-xs flex flex-col gap-2.5"
                    >
                      <div className="flex items-start gap-3">
                        {/* Product Thumbnail on List Card */}
                        <div className="w-16 h-16 rounded-2xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center">
                          {p.image ? (
                            <img
                              src={p.image}
                              alt={p.name}
                              className="w-full h-full object-cover"
                              loading="lazy"
                            />
                          ) : (
                            <Package className="w-6 h-6 text-slate-400" />
                          )}
                        </div>

                        <div className="flex-1 pr-1 min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700">
                              {p.category || 'Sembako'}
                            </span>
                            {p.barcode && (
                              <span className="text-[10px] font-mono bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded truncate max-w-[120px]">
                                #{p.barcode}
                              </span>
                            )}
                          </div>
                          <h4 className="font-bold text-sm text-slate-900 mt-0.5 line-clamp-1">{p.name}</h4>
                          <div className="flex flex-wrap items-center gap-2 mt-1 text-xs">
                            <span className="font-extrabold text-indigo-600">
                              {formatRp(p.price)}
                            </span>
                            <span className="text-slate-400 text-[11px]">
                              HPP: {formatRp(p.costPrice || 0)}
                            </span>
                            <span className="text-emerald-600 font-semibold text-[11px]">
                              +{formatRp(estProfit)}
                            </span>
                          </div>
                        </div>

                        {/* Edit & Delete Action Buttons */}
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            onClick={() => {
                              setProductToEdit(p);
                              setIsProductModalOpen(true);
                            }}
                            className="p-2 rounded-xl bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 transition"
                            title="Edit Produk"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(p.id)}
                            className="p-2 rounded-xl bg-slate-100 hover:bg-rose-50 hover:text-rose-600 text-slate-600 transition"
                            title="Hapus Produk"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Stock Adjuster */}
                      <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-500 font-medium">Stok:</span>
                          <span
                            className={`font-black px-2 py-0.5 rounded-lg text-xs ${
                              p.stock === 0
                                ? 'bg-rose-100 text-rose-700'
                                : p.stock <= 5
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}
                          >
                            {p.stock} pcs
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleQuickAddStock(p.id, 1)}
                            className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] active:scale-95 transition"
                          >
                            +1
                          </button>
                          <button
                            onClick={() => handleQuickAddStock(p.id, 5)}
                            className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] active:scale-95 transition"
                          >
                            +5
                          </button>
                          <button
                            onClick={() => handleQuickAddStock(p.id, 10)}
                            className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-[11px] active:scale-95 transition"
                          >
                            +10
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* ==================== TAB 3: LAPORAN (FINANCE & HISTORY) ==================== */}
        {activeTab === 'reports' && (
          <div className="space-y-3">
            {/* Filter Timeframe */}
            <div className="flex gap-1.5 bg-white p-1 rounded-2xl border border-slate-200">
              <button
                onClick={() => setReportFilter('today')}
                className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition ${
                  reportFilter === 'today'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Hari Ini
              </button>
              <button
                onClick={() => setReportFilter('yesterday')}
                className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition ${
                  reportFilter === 'yesterday'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Kemarin
              </button>
              <button
                onClick={() => setReportFilter('week')}
                className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition ${
                  reportFilter === 'week'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                7 Hari
              </button>
              <button
                onClick={() => setReportFilter('all')}
                className={`flex-1 py-1.5 rounded-xl font-bold text-xs transition ${
                  reportFilter === 'all'
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Semua
              </button>
            </div>

            {/* Income & Profit Summary Card */}
            <div className="p-4 rounded-3xl bg-gradient-to-br from-indigo-700 via-indigo-600 to-blue-700 text-white shadow-xl relative overflow-hidden">
              <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-32 h-32 rounded-full bg-white/10 blur-xl pointer-events-none" />

              <div className="flex items-center justify-between">
                <span className="text-xs text-indigo-200 font-medium">Total Omset Penjualan</span>
                <span className="text-[11px] px-2 py-0.5 rounded-full bg-white/20 font-semibold backdrop-blur-xs">
                  {reportTotals.count} Transaksi
                </span>
              </div>

              <div className="text-3xl font-black tracking-tight mt-1 mb-4">
                {formatRp(reportTotals.revenue)}
              </div>

              <div className="grid grid-cols-2 gap-2 pt-3 border-t border-white/20 text-xs">
                <div>
                  <span className="text-indigo-200 block text-[11px]">Modal Barang (HPP)</span>
                  <span className="font-bold text-sm text-slate-100">
                    {formatRp(reportTotals.cost)}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-indigo-200 block text-[11px]">Keuntungan Bersih</span>
                  <span className="font-extrabold text-sm text-emerald-300">
                    {formatRp(reportTotals.profit)}
                  </span>
                </div>
              </div>
            </div>

            {/* Export CSV Button */}
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-xs text-slate-700 uppercase tracking-wider">
                Riwayat Transaksi ({filteredTransactions.length})
              </h3>
              <button
                onClick={handleExportCSV}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-semibold text-xs hover:bg-slate-50 transition shadow-xs"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>Ekspor Excel/CSV</span>
              </button>
            </div>

            {/* Transaction Cards List */}
            <div className="space-y-2.5">
              {filteredTransactions.length === 0 ? (
                <div className="text-center py-10 bg-white rounded-3xl border border-slate-200 p-4">
                  <Clock className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-semibold text-slate-700">Belum Ada Transaksi</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Transaksi penjualan yang selesai akan tercatat otomatis di sini.
                  </p>
                </div>
              ) : (
                filteredTransactions.map((tx) => (
                  <div
                    key={tx.id}
                    className="p-3.5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2.5"
                  >
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-700">
                          #{tx.id.toString().slice(-6)}
                        </span>
                        <span className="text-[11px] text-slate-400">{tx.date}</span>
                      </div>
                      <span className="font-extrabold text-sm text-indigo-700">
                        {formatRp(tx.total)}
                      </span>
                    </div>

                    {/* Items breakdown list */}
                    <div className="space-y-1 text-xs text-slate-700 bg-slate-50/70 p-2.5 rounded-xl">
                      {tx.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center text-[11px]">
                          <span className="truncate pr-2">
                            {item.qty}x {item.name}
                          </span>
                          <span className="font-semibold text-slate-600 shrink-0">
                            {formatRp(item.price * item.qty)}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Payment details & reprint receipt button */}
                    <div className="flex items-center justify-between pt-1 text-xs">
                      <div className="text-[11px] text-slate-500">
                        Bayar: <strong className="text-slate-700">{formatRp(tx.paid)}</strong> (
                        {tx.paymentMethod === 'qris' ? 'QRIS' : 'Tunai'})
                        {tx.change > 0 && (
                          <span>
                            {' '}
                            • Kembali: <strong className="text-emerald-600">{formatRp(tx.change)}</strong>
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => handleReprint(tx)}
                        className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] transition"
                        title="Cetak Ulang Struk Thermal"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Cetak Struk</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </main>

      {/* Floating Cart Pill (Only on cashier tab when cart is not empty) */}
      {activeTab === 'cashier' && cartTotalQty > 0 && (
        <div
          onClick={() => setIsCartModalOpen(true)}
          className="fixed bottom-20 left-4 right-4 max-w-md mx-auto bg-slate-900 text-white rounded-2xl p-3.5 shadow-2xl flex items-center justify-between cursor-pointer border border-slate-800 z-40 active:scale-98 transition animate-in slide-in-from-bottom-4 duration-200"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black relative">
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 rounded-full text-[10px] flex items-center justify-center font-bold border-2 border-slate-900">
                {cartTotalQty}
              </span>
            </div>
            <div>
              <div className="text-[11px] text-slate-400 font-medium">
                Total Belanja ({cartTotalQty} item)
              </div>
              <div className="text-base font-extrabold text-white">
                {formatRp(cartTotalPrice)}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-white/10 px-3 py-1.5 rounded-xl font-bold text-xs text-indigo-300">
            <span>Bayar</span>
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      )}

      {/* Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-md mx-auto bg-white border-t border-slate-200 shadow-lg flex items-center justify-around z-30 pb-safe">
        <button
          onClick={() => setActiveTab('cashier')}
          className={`flex-1 py-2.5 flex flex-col items-center gap-1 transition ${
            activeTab === 'cashier' ? 'text-indigo-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <Store className="w-5 h-5" />
          <span className="text-[11px]">Kasir</span>
        </button>

        <button
          onClick={() => setActiveTab('products')}
          className={`flex-1 py-2.5 flex flex-col items-center gap-1 transition ${
            activeTab === 'products' ? 'text-indigo-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <Package className="w-5 h-5" />
          <span className="text-[11px]">Produk</span>
        </button>

        <button
          onClick={() => setActiveTab('reports')}
          className={`flex-1 py-2.5 flex flex-col items-center gap-1 transition ${
            activeTab === 'reports' ? 'text-indigo-600 font-bold' : 'text-slate-400 font-medium'
          }`}
        >
          <TrendingUp className="w-5 h-5" />
          <span className="text-[11px]">Laporan</span>
        </button>
      </nav>

      {/* Camera Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScanSuccess={handleScanSuccess}
        title={scannerTarget === 'cashier' ? 'Scan Barcode Kasir' : 'Scan Barcode Produk'}
      />

      {/* Cart & Checkout Modal */}
      <CartModal
        isOpen={isCartModalOpen}
        onClose={() => setIsCartModalOpen(false)}
        cart={cart}
        onUpdateQty={handleUpdateQty}
        onRemoveItem={handleRemoveFromCart}
        onClearCart={handleClearCart}
        onCheckout={handleCheckout}
      />

      {/* Product Add / Edit Modal */}
      <ProductModal
        isOpen={isProductModalOpen}
        onClose={() => setIsProductModalOpen(false)}
        onSave={handleSaveProduct}
        productToEdit={productToEdit}
        onOpenScanner={() => openScanner('product')}
        scannedBarcode={scannedBarcodeForProduct}
      />

      {/* Store Settings & Backup Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={setSettings}
        products={products}
        transactions={transactions}
        onRestoreData={(newProducts, newTransactions, newSettings) => {
          setProducts(newProducts);
          setTransactions(newTransactions);
          setSettings(newSettings);
        }}
        onResetData={() => {
          setConfirmModal({
            isOpen: true,
            title: 'Reset ke Data Demo Awal?',
            message: 'Semua perubahan data produk dan riwayat transaksi akan dikembalikan ke data demo awal toko.',
            confirmLabel: 'Ya, Reset Data',
            cancelLabel: 'Batal',
            isDestructive: true,
            onConfirm: () => {
              setProducts(INITIAL_PRODUCTS);
              setTransactions([]);
              setSettings(INITIAL_SETTINGS);
              setCart([]);
              showToast('Data berhasil direset ke demo awal', 'info');
            },
          });
        }}
        onOpenInstallModal={() => setIsInstallModalOpen(true)}
        onNotify={showToast}
      />

      {/* In-app Confirmation Dialog (replaces window.confirm) */}
      <ConfirmModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal((prev) => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        message={confirmModal.message}
        confirmLabel={confirmModal.confirmLabel}
        cancelLabel={confirmModal.cancelLabel}
        isDestructive={confirmModal.isDestructive}
      />

      {/* In-app Toast Notifications (replaces window.alert) */}
      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* Android PWA Install Guidance Modal */}
      <PWAInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        onTriggerInstall={install}
        isInstallable={isInstallable}
      />

      {/* Thermal Receipt Print Hidden Area */}
      <ReceiptPrintTemplate transaction={printTransaction} settings={settings} />

      {/* Offline Status Awareness */}
      <OfflineIndicator />
    </div>
  );
}
