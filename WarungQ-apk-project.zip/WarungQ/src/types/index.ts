export interface Product {
  id: number;
  name: string;
  price: number;
  costPrice: number;
  stock: number;
  barcode: string;
  category?: string;
  image?: string;
}

export interface CartItem {
  id: number;
  name: string;
  price: number;
  costPrice: number;
  qty: number;
  image?: string;
}

export interface Transaction {
  id: number;
  date: string;
  timestamp: number;
  total: number;
  paid: number;
  change: number;
  paymentMethod: 'cash' | 'qris';
  items: CartItem[];
}

export interface StoreSettings {
  storeName: string;
  storeAddress: string;
  storePhone: string;
  receiptFooter: string;
}
