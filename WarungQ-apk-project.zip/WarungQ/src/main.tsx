import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

import { registerSW } from 'virtual:pwa-register';

// Register Service Worker via vite-plugin-pwa
const updateSW = registerSW({
  immediate: true,
  onNeedRefresh() {
    if (confirm('Versi baru Warung KDM tersedia. Perbarui sekarang?')) {
      updateSW(true);
    }
  },
  onOfflineReady() {
    console.log('Warung KDM siap digunakan secara offline!');
  },
});

// Fallback registration for standalone browser compatibility
if ('serviceWorker' in navigator && !window.location.host.includes('localhost:3000')) {
  navigator.serviceWorker.register('/sw.js').catch(() => {});
}

createRoot(document.getElementById('root')!).render(<App />);
