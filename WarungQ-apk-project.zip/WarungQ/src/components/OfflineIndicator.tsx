import React from 'react';
import { WifiOff } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-40 max-w-md mx-auto flex items-center justify-between gap-2 rounded-2xl bg-slate-900/95 text-white px-4 py-2.5 text-xs font-medium shadow-2xl backdrop-blur-md border border-slate-700">
      <div className="flex items-center gap-2">
        <WifiOff className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
        <span>Mode Offline — Aplikasi tetap bisa digunakan!</span>
      </div>
      <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
        Lokal
      </span>
    </div>
  );
};
