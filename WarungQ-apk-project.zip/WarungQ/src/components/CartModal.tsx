import React, { useState, useEffect } from 'react';
import { Minus, Plus, Trash2, Printer, Check, X, QrCode, Banknote } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem } from '../types';
import { formatRp } from '../utils/constants';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQty: (id: number, delta: number) => void;
  onRemoveItem: (id: number) => void;
  onClearCart: () => void;
  onCheckout: (paidAmount: number, paymentMethod: 'cash' | 'qris', shouldPrint: boolean) => void;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  cart,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onCheckout,
}) => {
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'qris'>('cash');
  const [paidInput, setPaidInput] = useState<string>('');

  const totalAmount = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  useEffect(() => {
    if (isOpen) {
      setPaidInput(totalAmount > 0 ? totalAmount.toString() : '');
    }
  }, [isOpen, totalAmount]);

  const paidNumber = paymentMethod === 'qris' ? totalAmount : parseFloat(paidInput) || 0;
  const changeAmount = Math.max(0, paidNumber - totalAmount);
  const isInsufficient = paymentMethod === 'cash' && paidNumber < totalAmount;

  if (!isOpen) return null;

  const handleQuickCash = (amount: number) => {
    setPaymentMethod('cash');
    setPaidInput(amount.toString());
  };

  const handlePay = (shouldPrint: boolean) => {
    if (cart.length === 0) return;
    if (isInsufficient) {
      return;
    }

    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {
      // ignore
    }

    onCheckout(paidNumber, paymentMethod, shouldPrint);
    setPaidInput('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-lg rounded-t-3xl sm:rounded-3xl bg-slate-50 text-slate-900 shadow-2xl flex flex-col max-h-[92vh] border border-slate-200 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-white border-b border-slate-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold">
              {cart.reduce((s, i) => s + i.qty, 0)}
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">Keranjang Belanja</h3>
              <p className="text-xs text-slate-500">Periksa pesanan & proses pembayaran</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {cart.length > 0 && (
              <button
                onClick={onClearCart}
                className="text-xs text-rose-600 hover:text-rose-700 font-medium px-2 py-1 rounded-lg hover:bg-rose-50 transition"
              >
                Kosongkan
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5">
          {cart.length === 0 ? (
            <div className="text-center py-12 text-slate-400">
              <p className="text-sm">Keranjang masih kosong</p>
            </div>
          ) : (
            cart.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-3 bg-white rounded-2xl border border-slate-200/80 shadow-sm gap-3"
              >
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-12 h-12 rounded-xl object-cover border border-slate-100 shrink-0"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-indigo-50 border border-indigo-100/50 flex items-center justify-center shrink-0 text-indigo-500 font-bold text-xs">
                    {item.name.slice(0, 2).toUpperCase()}
                  </div>
                )}

                <div className="flex-1 pr-1 min-w-0">
                  <h4 className="font-semibold text-xs text-slate-800 line-clamp-1">{item.name}</h4>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-xs font-bold text-indigo-600">{formatRp(item.price)}</span>
                    <span className="text-[10px] text-slate-400">
                      Total: {formatRp(item.price * item.qty)}
                    </span>
                  </div>
                </div>

                {/* Qty Controls */}
                <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                  <button
                    onClick={() => onUpdateQty(item.id, -1)}
                    className="w-7 h-7 rounded-lg bg-white text-slate-700 flex items-center justify-center shadow-xs hover:bg-slate-200 active:scale-95 transition"
                  >
                    {item.qty === 1 ? <Trash2 className="w-3.5 h-3.5 text-rose-500" /> : <Minus className="w-3.5 h-3.5" />}
                  </button>

                  <span className="w-7 text-center font-bold text-xs text-slate-800">
                    {item.qty}
                  </span>

                  <button
                    onClick={() => onUpdateQty(item.id, 1)}
                    className="w-7 h-7 rounded-lg bg-white text-slate-700 flex items-center justify-center shadow-xs hover:bg-slate-200 active:scale-95 transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Payment Section */}
        {cart.length > 0 && (
          <div className="bg-white border-t border-slate-200 p-4 space-y-3.5 shadow-lg">
            {/* Total Summary */}
            <div className="p-3.5 rounded-2xl bg-indigo-50/80 border border-indigo-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-indigo-600 font-medium">Total Pembayaran</span>
                <div className="text-2xl font-extrabold text-indigo-900">{formatRp(totalAmount)}</div>
              </div>
              <div className="text-right">
                <span className="text-[11px] text-slate-500">Kembalian</span>
                <div className={`text-base font-bold ${changeAmount > 0 ? 'text-emerald-600' : 'text-slate-700'}`}>
                  {formatRp(changeAmount)}
                </div>
              </div>
            </div>

            {/* Payment Method Switcher */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setPaymentMethod('cash')}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition ${
                  paymentMethod === 'cash'
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                <Banknote className="w-4 h-4" />
                <span>Tunai (Cash)</span>
              </button>

              <button
                onClick={() => setPaymentMethod('qris')}
                className={`py-2 px-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition ${
                  paymentMethod === 'qris'
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                    : 'bg-slate-100 text-slate-700 border-slate-200 hover:bg-slate-200'
                }`}
              >
                <QrCode className="w-4 h-4" />
                <span>QRIS Non-Tunai</span>
              </button>
            </div>

            {/* Cash Payment Options */}
            {paymentMethod === 'cash' && (
              <div className="space-y-2">
                <div className="flex gap-1.5 overflow-x-auto pb-1 text-xs">
                  <button
                    onClick={() => handleQuickCash(totalAmount)}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-[11px] hover:bg-emerald-200 shrink-0 transition"
                  >
                    Uang Pas
                  </button>
                  {[10000, 20000, 50000, 100000].map((nominal) => (
                    <button
                      key={nominal}
                      onClick={() => handleQuickCash(nominal)}
                      className="px-2.5 py-1.5 rounded-lg bg-slate-100 text-slate-700 font-semibold text-[11px] hover:bg-slate-200 shrink-0 transition"
                    >
                      {formatRp(nominal)}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <input
                    type="number"
                    value={paidInput}
                    onChange={(e) => setPaidInput(e.target.value)}
                    placeholder="Masukkan nominal uang diterima (Rp)"
                    className={`w-full py-2.5 px-3.5 rounded-xl border text-sm font-semibold transition outline-none ${
                      isInsufficient
                        ? 'border-rose-400 bg-rose-50 text-rose-900 focus:border-rose-600'
                        : 'border-slate-300 bg-slate-50 focus:border-indigo-600 focus:bg-white'
                    }`}
                  />
                  {paidInput && (
                    <button
                      onClick={() => setPaidInput('')}
                      className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
                    >
                      Hapus
                    </button>
                  )}
                </div>

                {isInsufficient && (
                  <p className="text-[11px] text-rose-600 font-medium">
                    * Uang diterima kurang {formatRp(totalAmount - paidNumber)}
                  </p>
                )}
              </div>
            )}

            {/* Action Buttons */}
            <div className="grid grid-cols-2 gap-2.5 pt-1">
              <button
                onClick={() => handlePay(false)}
                disabled={isInsufficient}
                className="py-3 px-3 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition disabled:opacity-50"
              >
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Bayar Saja</span>
              </button>

              <button
                onClick={() => handlePay(true)}
                disabled={isInsufficient}
                className="py-3 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 active:scale-95 transition disabled:opacity-50"
              >
                <Printer className="w-4 h-4" />
                <span>Bayar & Cetak Struk</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
