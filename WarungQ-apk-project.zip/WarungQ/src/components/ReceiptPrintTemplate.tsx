import React from 'react';
import { Transaction, StoreSettings } from '../types';
import { formatRp } from '../utils/constants';

interface ReceiptPrintTemplateProps {
  transaction: Transaction | null;
  settings: StoreSettings;
}

export const ReceiptPrintTemplate: React.FC<ReceiptPrintTemplateProps> = ({
  transaction,
  settings,
}) => {
  if (!transaction) return null;

  return (
    <div
      id="receipt-print-area"
      className="fixed -left-[9999px] top-0 pointer-events-none print:left-0 print:top-0 print:pointer-events-auto print:static print:block"
    >
      <div style={{ textAlign: 'center', marginBottom: '8px' }}>
        <strong style={{ fontSize: '13px', display: 'block', letterSpacing: '1px' }}>
          {settings.storeName.toUpperCase()}
        </strong>
        <span style={{ fontSize: '10px', color: '#444', display: 'block' }}>
          {settings.storeAddress}
        </span>
        <span style={{ fontSize: '10px', color: '#444', display: 'block' }}>
          Telp: {settings.storePhone}
        </span>
      </div>

      <div className="print-dashed"></div>

      <div style={{ fontSize: '10px', marginBottom: '6px' }}>
        <div className="print-flex-between">
          <span>No: #{transaction.id.toString().slice(-6)}</span>
          <span>{transaction.date}</span>
        </div>
        <div className="print-flex-between">
          <span>Kasir: Admin</span>
          <span>Metode: {transaction.paymentMethod === 'qris' ? 'QRIS' : 'TUNAI'}</span>
        </div>
      </div>

      <div className="print-dashed"></div>

      <div style={{ margin: '6px 0' }}>
        {transaction.items.map((item, idx) => (
          <div key={idx} style={{ marginBottom: '5px' }}>
            <div style={{ fontWeight: 600 }}>{item.name}</div>
            <div className="print-flex-between">
              <span>
                {item.qty} x {formatRp(item.price)}
              </span>
              <span>{formatRp(item.price * item.qty)}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="print-dashed"></div>

      <div style={{ fontSize: '11px' }}>
        <div className="print-flex-between" style={{ fontWeight: 700, fontSize: '12px' }}>
          <span>TOTAL</span>
          <span>{formatRp(transaction.total)}</span>
        </div>
        <div className="print-flex-between">
          <span>BAYAR</span>
          <span>{formatRp(transaction.paid)}</span>
        </div>
        <div className="print-flex-between">
          <span>KEMBALI</span>
          <span>{formatRp(transaction.change)}</span>
        </div>
      </div>

      <div className="print-dashed"></div>

      <div style={{ textAlign: 'center', fontSize: '10px', marginTop: '8px', paddingBottom: '10px' }}>
        <div>{settings.receiptFooter}</div>
        <div style={{ marginTop: '4px', fontSize: '9px', color: '#666' }}>
          *** Simpan struk ini sebagai bukti transaksi ***
        </div>
      </div>
    </div>
  );
};
