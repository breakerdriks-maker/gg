import React, { useState } from 'react';
import { Download, Sparkles, Smartphone, CheckCircle2 } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { PWAInstallModal } from './PWAInstallModal';

export const PWAInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  // If already running in standalone / installed mode, show a small badge or hide
  if (isInstalled) {
    return (
      <div className="bg-emerald-600/10 border-b border-emerald-500/20 px-3 py-1.5 flex items-center justify-center gap-1.5 text-[11px] font-semibold text-emerald-700">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
        <span>Aplikasi Warung KDM Terpasang di Perangkat</span>
      </div>
    );
  }

  if (isDismissed) return null;

  return (
    <>
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-blue-900 text-white px-3.5 py-2.5 shadow-md flex items-center justify-between gap-3 text-xs border-b border-indigo-700/50">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20 flex items-center justify-center shrink-0">
            <Smartphone className="w-4 h-4 text-emerald-300" />
          </div>
          <div className="truncate">
            <div className="font-bold flex items-center gap-1.5 leading-tight">
              <span>Instal Warung KDM di HP Android</span>
              <span className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.2 rounded bg-amber-400 text-slate-950 font-black text-[9px] uppercase tracking-wide">
                <Sparkles className="w-2.5 h-2.5" /> APK/PWA
              </span>
            </div>
            <p className="text-[10px] text-indigo-200 truncate mt-0.5">
              Lebih cepat, layar penuh, & bisa dipakai offline tanpa kuota!
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={async () => {
              if (isInstallable) {
                const installed = await install();
                if (!installed) {
                  setIsModalOpen(true);
                }
              } else {
                setIsModalOpen(true);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-950/20 active:scale-95 transition"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Pasang Sekarang</span>
          </button>

          <button
            onClick={() => setIsDismissed(true)}
            className="text-indigo-300 hover:text-white p-1 rounded text-xs"
            title="Tutup banner"
          >
            ✕
          </button>
        </div>
      </div>

      <PWAInstallModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onTriggerInstall={install}
        isInstallable={isInstallable}
      />
    </>
  );
};
