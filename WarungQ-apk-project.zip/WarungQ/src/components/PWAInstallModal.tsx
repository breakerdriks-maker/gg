import React from 'react';
import { Smartphone, CheckCircle, Download, X, MoreVertical, PlusSquare } from 'lucide-react';

interface PWAInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTriggerInstall: () => Promise<boolean>;
  isInstallable: boolean;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  isOpen,
  onClose,
  onTriggerInstall,
  isInstallable,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-3xl bg-white text-slate-900 shadow-2xl overflow-hidden border border-slate-100">
        {/* Header with App Icon */}
        <div className="bg-gradient-to-r from-indigo-600 via-indigo-700 to-blue-600 p-6 text-white text-center relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full bg-white/20 hover:bg-white/30 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-white p-2 shadow-lg flex items-center justify-center">
            <img src="/icon.svg" alt="Warung KDM" className="w-12 h-12" />
          </div>
          <h2 className="text-xl font-bold">Pasang Warung KDM di HP</h2>
          <p className="text-xs text-indigo-100 mt-1">
            Akses langsung dari layar utama Android tanpa perlu ketik alamat browser lagi!
          </p>
        </div>

        {/* Content Body */}
        <div className="p-5 space-y-4 text-sm max-h-[70vh] overflow-y-auto">
          {/* Benefit cards */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-3 rounded-xl bg-indigo-50 border border-indigo-100 flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-indigo-950 block">Mulus & Kilat</span>
                <span className="text-indigo-800 text-[11px]">Buka instan 1 sentuhan di HP</span>
              </div>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-100 flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold text-emerald-950 block">Offline Mode</span>
                <span className="text-emerald-800 text-[11px]">Tetap bisa catat transaksi</span>
              </div>
            </div>
          </div>

          {/* Direct Install Button if Browser Supports beforeinstallprompt */}
          {isInstallable ? (
            <div className="bg-indigo-600 text-white p-4 rounded-2xl text-center shadow-md">
              <p className="text-xs font-medium mb-3 text-indigo-100">
                HP Android Anda mendukung instalasi langsung 1-klik!
              </p>
              <button
                onClick={async () => {
                  const success = await onTriggerInstall();
                  if (success) onClose();
                }}
                className="w-full py-3 bg-white text-indigo-700 font-bold rounded-xl shadow-lg hover:bg-slate-50 active:scale-95 transition flex items-center justify-center gap-2 text-sm"
              >
                <Download className="w-5 h-5 text-indigo-600" />
                Instal Aplikasi Sekarang
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
                Langkah Mudah Instal di Browser Chrome Android:
              </h3>

              <div className="space-y-2.5">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    1
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Buka Menu Browser</p>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      Ketuk ikon titik tiga <MoreVertical className="w-3.5 h-3.5 inline text-slate-700" /> di pojok kanan atas browser Chrome.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    2
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Pilih Instal / Tambahkan</p>
                    <p className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      Pilih menu <span className="font-semibold text-indigo-600">"Instal aplikasi"</span> atau <span className="font-semibold text-indigo-600">"Tambahkan ke Layar Utama"</span> <PlusSquare className="w-3.5 h-3.5 inline" />.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    3
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Selesai & Buka Kapan Saja</p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Ikon <span className="font-semibold text-slate-700">Warung KDM</span> akan otomatis muncul di layar utama HP Anda seperti aplikasi Play Store!
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Quick FAQ info */}
          <div className="rounded-xl p-3 bg-amber-50 border border-amber-200/60 text-[11px] text-amber-900 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-amber-600 shrink-0" />
            <span>
              Aplikasi ini adalah <strong>Progressive Web App (PWA)</strong> resmi, ringan (&lt; 2 MB), tidak membebani memori HP.
            </span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs transition"
          >
            Mengerti & Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
