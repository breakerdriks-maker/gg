import { Product, StoreSettings } from '../types';

export const INITIAL_SETTINGS: StoreSettings = {
  storeName: 'WARUNG KDM',
  storeAddress: 'Jl. Raya Utama No. 88, KDM',
  storePhone: '0812-3456-7890',
  receiptFooter: 'Terima Kasih Atas Kunjungan Anda!',
};

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'Minyak Goreng 1L',
    price: 18500,
    costPrice: 15500,
    stock: 24,
    barcode: '8991234001',
    category: 'Sembako',
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 2,
    name: 'Beras Ramos 5kg',
    price: 72000,
    costPrice: 63000,
    stock: 15,
    barcode: '8991234002',
    category: 'Sembako',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 3,
    name: 'Indomie Goreng Spesial',
    price: 3500,
    costPrice: 2800,
    stock: 80,
    barcode: '8991234003',
    category: 'Makanan',
    image: 'https://images.unsplash.com/photo-1612927601601-6638404737ce?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 4,
    name: 'Gula Pasir 1kg',
    price: 17500,
    costPrice: 15000,
    stock: 30,
    barcode: '8991234004',
    category: 'Sembako',
    image: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 5,
    name: 'Telur Ayam 1kg',
    price: 29000,
    costPrice: 25000,
    stock: 20,
    barcode: '8991234005',
    category: 'Sembako',
    image: 'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 6,
    name: 'Kopi Kapal Api Special 165g',
    price: 15000,
    costPrice: 12500,
    stock: 25,
    barcode: '8991234006',
    category: 'Minuman',
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 7,
    name: 'Aqua Botol 600ml',
    price: 4000,
    costPrice: 2800,
    stock: 48,
    barcode: '8991234007',
    category: 'Minuman',
    image: 'https://images.unsplash.com/photo-1548839140-29a749e1bc4e?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 8,
    name: 'Teh Botol Sosro 450ml',
    price: 6000,
    costPrice: 4500,
    stock: 36,
    barcode: '8991234008',
    category: 'Minuman',
    image: 'https://images.unsplash.com/photo-1556679343-c7306c1976bc?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 9,
    name: 'Sabun Lifebuoy Total 10',
    price: 4500,
    costPrice: 3200,
    stock: 40,
    barcode: '8991234009',
    category: 'Kebersihan',
    image: 'https://images.unsplash.com/photo-1600857544200-b2f666a9a2ec?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 10,
    name: 'Deterjen Rinso Molto 770g',
    price: 21000,
    costPrice: 18000,
    stock: 18,
    barcode: '8991234010',
    category: 'Kebersihan',
    image: 'https://images.unsplash.com/photo-1585670270638-7a5a8784d1fa?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 11,
    name: 'Susu Kental Manis Frisian Flag',
    price: 12500,
    costPrice: 10500,
    stock: 22,
    barcode: '8991234011',
    category: 'Makanan',
    image: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?w=400&auto=format&fit=crop&q=80',
  },
  {
    id: 12,
    name: 'Tepung Terigu Segitiga Biru 1kg',
    price: 13000,
    costPrice: 11000,
    stock: 25,
    barcode: '8991234012',
    category: 'Sembako',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=400&auto=format&fit=crop&q=80',
  },
];

export const formatRp = (num: number): string => {
  return 'Rp ' + Math.round(num || 0).toLocaleString('id-ID');
};

export const formatDate = (timestamp: number | string | Date): string => {
  const d = new Date(timestamp);
  return d.toLocaleString('id-ID', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });
};
