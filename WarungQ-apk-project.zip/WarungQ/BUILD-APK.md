# Cara dapat APK WarungQ (gratis, tanpa install apa pun di PC)
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder .github).
2. Buka tab **Actions** > **Build APK** > **Run workflow** (otomatis jalan juga saat upload).
3. Tunggu ±5 menit, buka run yang selesai, unduh artifact **WarungQ-apk** (zip berisi app-debug.apk).
4. Kirim app-debug.apk ke HP Android, buka, izinkan "Install dari sumber tidak dikenal". Selesai.
