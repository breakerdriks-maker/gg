import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

function createPng(width, height, drawFn) {
  const rawData = Buffer.alloc(height * (1 + width * 4));

  for (let y = 0; y < height; y++) {
    const rowOffset = y * (1 + width * 4);
    rawData[rowOffset] = 0; // Filter type 0
    for (let x = 0; x < width; x++) {
      const pixelOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawData[pixelOffset] = r;
      rawData[pixelOffset + 1] = g;
      rawData[pixelOffset + 2] = b;
      rawData[pixelOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawData);

  function crc32(buf) {
    let c = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      c ^= buf[i];
      for (let j = 0; j < 8; j++) {
        c = (c >>> 1) ^ (-(c & 1) & 0xedb88320);
      }
    }
    return (c ^ 0xffffffff) >>> 0;
  }

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcBuf = Buffer.alloc(4);
    const full = Buffer.concat([typeBuf, data]);
    crcBuf.writeUInt32BE(crc32(full), 0);
    return Buffer.concat([len, full, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8;
  ihdr[9] = 6; // RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;

  return Buffer.concat([
    signature,
    makeChunk('IHDR', ihdr),
    makeChunk('IDAT', compressed),
    makeChunk('IEND', Buffer.alloc(0)),
  ]);
}

function drawStandardIcon(x, y, w, h) {
  const cx = w / 2;
  const cy = h / 2;
  const radius = w * 0.22;

  const dx = Math.max(0, Math.abs(x - cx) - (cx - radius));
  const dy = Math.max(0, Math.abs(y - cy) - (cy - radius));
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > radius) {
    return [0, 0, 0, 0];
  }

  return getIconPixel(x, y, w, h, false);
}

function drawMaskableIcon(x, y, w, h) {
  return getIconPixel(x, y, w, h, true);
}

function getIconPixel(x, y, w, h, isMaskable) {
  const normX = x / w;
  const normY = y / h;

  // Background Gradient (Vibrant Cyan-Blue to Royal Blue: #38bdf8 to #1d4ed8)
  const t = (normX + normY) / 2;
  const bgR = Math.round(56 * (1 - t) + 29 * t);
  const bgG = Math.round(189 * (1 - t) + 78 * t);
  const bgB = Math.round(248 * (1 - t) + 216 * t);

  const scale = isMaskable ? 0.65 : 0.82;
  const nx = (normX - 0.5) / scale + 0.5;
  const ny = (normY - 0.5) / scale + 0.5;

  // 1. Gold Coin in lower right: center (0.75, 0.74), radius 0.15
  const coinDist = Math.hypot(nx - 0.75, ny - 0.74);
  if (coinDist <= 0.15) {
    if (coinDist >= 0.138) return [30, 41, 59, 255]; // coin dark border
    if (coinDist >= 0.12) return [202, 138, 4, 255]; // gold outer rim
    if (coinDist >= 0.10) return [250, 204, 21, 255]; // bright gold face
    // Center "Rp" area
    if (nx >= 0.68 && nx <= 0.82 && ny >= 0.70 && ny <= 0.78) {
      return [120, 53, 15, 255]; // dark amber "Rp"
    }
    return [254, 240, 138, 255];
  }

  // 2. Red & White Awning Canopy at top: nx 0.28 to 0.72, ny 0.18 to 0.32
  if (nx >= 0.28 && nx <= 0.72 && ny >= 0.18 && ny <= 0.32) {
    if (nx <= 0.29 || nx >= 0.71 || ny <= 0.19 || ny >= 0.31) return [30, 41, 59, 255];
    // Alternating red and white vertical stripes
    const stripeIndex = Math.floor((nx - 0.29) / 0.084);
    if (stripeIndex % 2 === 0) {
      return [220, 38, 38, 255]; // Red stripe
    }
    return [255, 255, 255, 255]; // White stripe
  }

  // 3. Monitor Bezel & Glowing Blue Screen: nx 0.32 to 0.68, ny 0.32 to 0.54
  if (nx >= 0.32 && nx <= 0.68 && ny >= 0.32 && ny <= 0.54) {
    if (nx <= 0.34 || nx >= 0.66 || ny <= 0.33 || ny >= 0.53) {
      return [241, 245, 249, 255]; // light gray monitor bezel
    }
    // Screen interior (glowing cyan-blue)
    // "Rp" gold text on left of screen: nx 0.38 to 0.48, ny 0.38 to 0.48
    if (nx >= 0.37 && nx <= 0.48 && ny >= 0.38 && ny <= 0.48) {
      return [251, 191, 36, 255]; // Golden Rp
    }
    // White Shopping Cart on right of screen: nx 0.52 to 0.63, ny 0.39 to 0.48
    if (nx >= 0.52 && nx <= 0.63 && ny >= 0.39 && ny <= 0.47) {
      return [255, 255, 255, 255]; // White cart
    }
    return [2, 132, 199, 255]; // Rich blue screen #0284c7
  }

  // 4. Keyboard Deck: nx 0.25 to 0.75, ny 0.54 to 0.70
  if (nx >= 0.25 && nx <= 0.75 && ny >= 0.54 && ny <= 0.70) {
    // Buttons simulation
    if (ny >= 0.56 && ny <= 0.61) {
      if (nx >= 0.28 && nx <= 0.50) {
        return ((Math.floor((nx - 0.28) * 40)) % 2 === 0) ? [255, 255, 255, 255] : [203, 213, 225, 255];
      }
      if (nx >= 0.54 && nx <= 0.62) return [239, 68, 68, 255]; // Red key
      if (nx >= 0.64 && nx <= 0.72) return [59, 130, 246, 255]; // Blue key
    }
    if (ny >= 0.63 && ny <= 0.68) {
      if (nx >= 0.28 && nx <= 0.50) {
        return ((Math.floor((nx - 0.28) * 40)) % 2 === 0) ? [255, 255, 255, 255] : [203, 213, 225, 255];
      }
      if (nx >= 0.54 && nx <= 0.62) return [245, 158, 11, 255]; // Orange key
      if (nx >= 0.64 && nx <= 0.72) return [16, 185, 129, 255]; // Green key
    }
    return [226, 232, 240, 255]; // Base body
  }

  // 5. Bottom Base & Receipt Paper: nx 0.24 to 0.76, ny 0.70 to 0.83
  if (nx >= 0.24 && nx <= 0.76 && ny >= 0.70 && ny <= 0.83) {
    // White receipt paper coming out: nx 0.30 to 0.56, ny 0.73 to 0.83
    if (nx >= 0.30 && nx <= 0.56 && ny >= 0.73 && ny <= 0.83) {
      return [255, 255, 255, 255];
    }
    // Slot
    if (nx >= 0.28 && nx <= 0.60 && ny >= 0.72 && ny <= 0.75) {
      return [30, 41, 59, 255];
    }
    return [203, 213, 225, 255];
  }

  return [bgR, bgG, bgB, 255];
}

const publicDir = path.resolve('public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

console.log('Generating updated 3D PWA icons...');
const pwa192 = createPng(192, 192, drawStandardIcon);
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), pwa192);

const pwa512 = createPng(512, 512, drawStandardIcon);
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), pwa512);

const pwaMaskable = createPng(512, 512, drawMaskableIcon);
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pwaMaskable);

const appleTouchIcon = createPng(180, 180, drawStandardIcon);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), appleTouchIcon);

const favicon = createPng(64, 64, drawStandardIcon);
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), favicon);

console.log('All icons regenerated successfully!');
