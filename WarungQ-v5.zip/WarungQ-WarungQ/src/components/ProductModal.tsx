import React, { useState, useEffect, useRef } from 'react';
import { X, QrCode, Save, PackagePlus, Edit3, Image as ImageIcon, Camera, Trash2, Sparkles, Link as LinkIcon } from 'lucide-react';
import { Product } from '../types';
import { compressImage, PRESET_PRODUCT_IMAGES } from '../utils/imageHelper';
import { CameraCaptureModal } from './CameraCaptureModal';

interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (productData: Omit<Product, 'id'>, id?: number) => void;
  productToEdit?: Product | null;
  onOpenScanner: () => void;
  scannedBarcode?: string | null;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  productToEdit,
  onOpenScanner,
  scannedBarcode,
}) => {
  const [name, setName] = useState('');
  const [price, setPrice] = useState<string>('');
  const [costPrice, setCostPrice] = useState<string>('');
  const [stock, setStock] = useState<string>('');
  const [barcode, setBarcode] = useState('');
  const [category, setCategory] = useState('Sembako');
  const [image, setImage] = useState<string>('');
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [isCompressing, setIsCompressing] = useState(false);
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (productToEdit) {
      setName(productToEdit.name || '');
      setPrice(productToEdit.price != null ? productToEdit.price.toString() : '');
      setCostPrice(productToEdit.costPrice != null ? productToEdit.costPrice.toString() : '');
      setStock(productToEdit.stock != null ? productToEdit.stock.toString() : '0');
      setBarcode(productToEdit.barcode || '');
      setCategory(productToEdit.category || 'Sembako');
      setImage(productToEdit.image || '');
    } else {
      setName('');
      setPrice('');
      setCostPrice('');
      setStock('10');
      setBarcode(scannedBarcode || '');
      setCategory('Sembako');
      setImage('');
    }
    setShowUrlInput(false);
    setValidationError(null);
  }, [productToEdit, isOpen]);

  // When a barcode is scanned from camera, apply it
  useEffect(() => {
    if (scannedBarcode) {
      setBarcode(scannedBarcode);
    }
  }, [scannedBarcode]);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsCompressing(true);
      const compressedDataUrl = await compressImage(file, 400, 400, 0.82);
      setImage(compressedDataUrl);
      setValidationError(null);
    } catch (err) {
      console.error('Error processing image:', err);
      setValidationError('Gagal memproses gambar. Coba gambar lain.');
    } finally {
      setIsCompressing(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);
    if (!name.trim()) {
      setValidationError('Nama produk tidak boleh kosong!');
      return;
    }
    const numPrice = parseFloat(price) || 0;
    if (numPrice <= 0) {
      setValidationError('Harga jual produk harus lebih besar dari 0!');
      return;
    }

    const numCost = parseFloat(costPrice) || 0;
    const numStock = parseInt(stock) || 0;

    onSave(
      {
        name: name.trim(),
        price: numPrice,
        costPrice: numCost,
        stock: Math.max(0, numStock),
        barcode: barcode.trim(),
        category,
        image: image.trim() || undefined,
      },
      productToEdit?.id
    );
    onClose();
  };

  return (
    <>
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white text-slate-900 shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
              {productToEdit ? <Edit3 className="w-4 h-4" /> : <PackagePlus className="w-4 h-4" />}
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">
                {productToEdit ? 'Edit Produk' : 'Tambah Produk Baru'}
              </h3>
              <p className="text-xs text-slate-500">Kelola foto, harga & stok inventaris</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3.5 max-h-[78vh] overflow-y-auto">
          {validationError && (
            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {validationError}
            </div>
          )}

          {/* Product Image Section */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                <span>Foto / Gambar Produk</span>
              </span>
              <span className="text-[11px] text-slate-400 font-normal">Opsional</span>
            </label>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col gap-2.5">
              <div className="flex items-center gap-3">
                {/* Image Preview thumbnail */}
                <div className="w-20 h-20 rounded-xl bg-slate-200 border border-slate-300 overflow-hidden relative shrink-0 flex items-center justify-center group shadow-xs">
                  {image ? (
                    <>
                      <img
                        src={image}
                        alt="Preview"
                        className="w-full h-full object-cover"
                        onError={() => setImage('')}
                      />
                      <button
                        type="button"
                        onClick={() => setImage('')}
                        className="absolute inset-0 bg-slate-900/60 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition"
                        title="Hapus foto"
                      >
                        <Trash2 className="w-4 h-4 text-rose-300" />
                      </button>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400">
                      <ImageIcon className="w-6 h-6 stroke-1 mb-0.5" />
                      <span className="text-[9px] font-medium">Tanpa Foto</span>
                    </div>
                  )}

                  {isCompressing && (
                    <div className="absolute inset-0 bg-slate-900/70 text-white flex items-center justify-center text-[10px] font-bold">
                      Memuat...
                    </div>
                  )}
                </div>

                {/* Upload & Action buttons */}
                <div className="flex-1 space-y-1.5">
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => setIsCameraOpen(true)}
                      className="flex-1 py-2 px-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95 shadow-sm shadow-indigo-600/20"
                    >
                      <Camera className="w-3.5 h-3.5" />
                      <span>{image ? 'Foto Ulang' : 'Ambil Foto'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="py-2 px-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
                      title="Pilih dari galeri"
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      <span>Galeri</span>
                    </button>

                    {image && (
                      <button
                        type="button"
                        onClick={() => setImage('')}
                        className="p-2 rounded-xl bg-slate-200 hover:bg-rose-100 hover:text-rose-600 text-slate-600 transition"
                        title="Hapus foto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <button
                      type="button"
                      onClick={() => setShowUrlInput(!showUrlInput)}
                      className="text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1"
                    >
                      <LinkIcon className="w-3 h-3" />
                      <span>{showUrlInput ? 'Tutup URL' : 'Tempel URL Gambar'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Hidden file input supporting camera capture & gallery */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              {/* URL Input Form */}
              {showUrlInput && (
                <div className="flex gap-1.5 pt-1">
                  <input
                    type="url"
                    value={image}
                    onChange={(e) => setImage(e.target.value)}
                    placeholder="https://contoh.com/gambar-produk.jpg"
                    className="flex-1 py-1.5 px-2.5 rounded-lg border border-slate-300 text-xs outline-none focus:border-indigo-600 bg-white"
                  />
                  {image && (
                    <button
                      type="button"
                      onClick={() => setShowUrlInput(false)}
                      className="px-2.5 py-1.5 bg-slate-200 text-slate-700 rounded-lg text-xs font-semibold"
                    >
                      OK
                    </button>
                  )}
                </div>
              )}

              {/* Quick Image Presets */}
              <div className="pt-2 border-t border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 flex items-center gap-1 mb-1.5">
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  <span>Pilih Gambar Cepat (Rekomendasi):</span>
                </span>
                <div className="flex gap-1 overflow-x-auto pb-1 no-scrollbar">
                  {PRESET_PRODUCT_IMAGES.map((preset) => (
                    <button
                      key={preset.name}
                      type="button"
                      onClick={() => {
                        setImage(preset.url);
                        setShowUrlInput(false);
                      }}
                      className="px-2 py-1 rounded-lg bg-white hover:bg-indigo-50 border border-slate-200 hover:border-indigo-300 text-slate-700 text-[11px] font-medium whitespace-nowrap shrink-0 flex items-center gap-1 transition active:scale-95"
                    >
                      <span>{preset.icon}</span>
                      <span>{preset.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Nama Produk */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Nama Produk <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Contoh: Minyak Goreng Bimoli 1L"
              className="w-full py-2.5 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none text-sm transition"
            />
          </div>

          {/* Kategori */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Kategori Produk</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full py-2.5 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none text-sm bg-white transition"
            >
              <option value="Sembako">Sembako</option>
              <option value="Makanan">Makanan & Snack</option>
              <option value="Minuman">Minuman</option>
              <option value="Kebersihan">Kebersihan & Sabun</option>
              <option value="Lainnya">Lain-lain</option>
            </select>
          </div>

          {/* Pricing Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Harga Jual (Rp) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                required
                min="0"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder="15000"
                className="w-full py-2.5 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none text-sm font-semibold text-indigo-700 transition"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Harga Modal (HPP)
              </label>
              <input
                type="number"
                min="0"
                value={costPrice}
                onChange={(e) => setCostPrice(e.target.value)}
                placeholder="12000"
                className="w-full py-2.5 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none text-sm font-semibold text-slate-600 transition"
              />
            </div>
          </div>

          {/* Stock & Barcode */}
          <div className="grid grid-cols-5 gap-3">
            <div className="col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Jumlah Stok
              </label>
              <input
                type="number"
                min="0"
                value={stock}
                onChange={(e) => setStock(e.target.value)}
                placeholder="10"
                className="w-full py-2.5 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 focus:ring-2 focus:ring-indigo-100 outline-none text-sm font-bold text-slate-800 transition"
              />
            </div>

            <div className="col-span-3">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Barcode Produk
              </label>
              <div className="flex">
                <input
                  type="text"
                  value={barcode}
                  onChange={(e) => setBarcode(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') e.preventDefault();
                  }}
                  placeholder="Scan / ketik barcode"
                  className="w-full py-2.5 px-3 rounded-l-xl border border-r-0 border-slate-300 focus:border-indigo-600 outline-none text-xs transition"
                />
                <button
                  type="button"
                  onClick={onOpenScanner}
                  className="px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-r-xl flex items-center justify-center transition active:scale-95"
                  title="Scan dengan kamera"
                >
                  <QrCode className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-2 flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs transition"
            >
              Batal
            </button>
            <button
              type="submit"
              className="flex-2 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/30 transition active:scale-95"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Data</span>
            </button>
          </div>
        </form>
      </div>
    </div>
      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(dataUrl) => {
          setImage(dataUrl);
          setValidationError(null);
        }}
      />
    </>
  );
};
