import React, { useState } from 'react';
import { StoreSettings, Product, Transaction } from '../types';
import { X, Store, Save, Download, Upload, RotateCcw, Smartphone, ShieldCheck, ScanLine } from 'lucide-react';
import { saveFileAs } from '../utils/nativeBridge';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: StoreSettings;
  onSaveSettings: (settings: StoreSettings) => void;
  products: Product[];
  transactions: Transaction[];
  onRestoreData: (products: Product[], transactions: Transaction[], settings: StoreSettings) => void;
  onResetData: () => void;
  onOpenInstallModal: () => void;
  onNotify?: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSaveSettings,
  products,
  transactions,
  onRestoreData,
  onResetData,
  onOpenInstallModal,
  onNotify,
}) => {
  const [storeName, setStoreName] = useState(settings.storeName);
  const [storeAddress, setStoreAddress] = useState(settings.storeAddress);
  const [storePhone, setStorePhone] = useState(settings.storePhone);
  const [receiptFooter, setReceiptFooter] = useState(settings.receiptFooter);
  const [receiptPaper, setReceiptPaper] = useState<'58' | '80' | 'a4'>(settings.receiptPaper ?? '58');
  const [hardwareScanner, setHardwareScanner] = useState<boolean>(settings.hardwareScanner !== false);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings({
      storeName: storeName.trim() || 'WARUNG KDM',
      storeAddress: storeAddress.trim(),
      storePhone: storePhone.trim(),
      receiptFooter: receiptFooter.trim(),
      receiptPaper,
      hardwareScanner,
    });
    if (onNotify) onNotify('Pengaturan warung berhasil disimpan!', 'success');
    onClose();
  };

  const handleExportBackup = async () => {
    const backupData = {
      app: 'Warung KDM POS',
      version: '1.1.0',
      exportedAt: new Date().toISOString(),
      settings: { ...settings, storeName, storeAddress, storePhone, receiptFooter, receiptPaper, hardwareScanner },
      products,
      transactions,
    };
    const filename = `backup-warung-kdm-${new Date().toISOString().slice(0, 10)}.json`;
    const result = await saveFileAs(filename, 'application/json', JSON.stringify(backupData, null, 2));
    if (!onNotify) return;
    if (result === 'saved') onNotify('Cadangan berhasil disimpan', 'success');
    else if (result === 'cancelled') onNotify('Penyimpanan dibatalkan', 'info');
    else onNotify('Gagal menyimpan cadangan', 'error');
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const input = e.target;
    const file = input.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (Array.isArray(parsed.products) && Array.isArray(parsed.transactions)) {
          onRestoreData(parsed.products, parsed.transactions, parsed.settings || settings);
          if (onNotify) onNotify('Data berhasil dipulihkan dari cadangan!', 'success');
          onClose();
        } else {
          if (onNotify) onNotify('Format file cadangan tidak sesuai.', 'error');
        }
      } catch {
        if (onNotify) onNotify('Gagal membaca file JSON cadangan.', 'error');
      }
    };
    reader.onloadend = () => {
      input.value = '';
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/70 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white text-slate-900 shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-600 flex items-center justify-center">
              <Store className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-base text-slate-900">Pengaturan Warung</h3>
              <p className="text-xs text-slate-500">Profil toko, printer struk & cadangan</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* Android PWA Install shortcut */}
          <div className="p-3.5 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-indigo-950">Instal Aplikasi di HP</h4>
                <p className="text-[11px] text-indigo-700">Panduan & pasang ke homescreen</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenInstallModal();
              }}
              className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 transition"
            >
              Buka Panduan
            </button>
          </div>

          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Nama Warung / Toko
              </label>
              <input
                type="text"
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 outline-none text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Alamat Warung</label>
              <input
                type="text"
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 outline-none text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">No. WhatsApp / HP</label>
              <input
                type="text"
                value={storePhone}
                onChange={(e) => setStorePhone(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 outline-none text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Pesan Footer Struk Thermal
              </label>
              <input
                type="text"
                value={receiptFooter}
                onChange={(e) => setReceiptFooter(e.target.value)}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 outline-none text-sm"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Ukuran Kertas Struk</label>
              <select
                value={receiptPaper}
                onChange={(e) => setReceiptPaper(e.target.value as '58' | '80' | 'a4')}
                className="w-full py-2 px-3 rounded-xl border border-slate-300 focus:border-indigo-600 outline-none text-sm bg-white"
              >
                <option value="58">Thermal 58 mm</option>
                <option value="80">Thermal 80 mm</option>
                <option value="a4">Kertas biasa (A4)</option>
              </select>
            </div>

            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hardwareScanner}
                  onChange={(e) => setHardwareScanner(e.target.checked)}
                  className="mt-0.5 w-4 h-4 accent-indigo-600"
                />
                <span>
                  <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <ScanLine className="w-3.5 h-3.5 text-indigo-600" />
                    Scanner barcode perangkat keras
                  </span>
                  <span className="block text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Untuk scanner USB (OTG), USB Type-C, Bluetooth, atau nirkabel. Atur scanner ke mode
                    keyboard (HID) dengan akhiran Enter, sambungkan ke HP, lalu scan di halaman Kasir. Saat
                    menambah produk, ketuk kolom Barcode dulu sebelum scan.
                  </span>
                </span>
              </label>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <Save className="w-4 h-4" />
              <span>Simpan Pengaturan</span>
            </button>
          </form>

          {/* Backup & Restore */}
          <div className="pt-3 border-t border-slate-200">
            <h4 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Cadangan & Pemulihan Data</span>
            </h4>
            <p className="text-[11px] text-slate-500 mb-2">
              Saat menyimpan, pilih folder tujuan mana saja (Download, Dokumen, kartu SD, Google Drive, dll).
              Untuk memulihkan, pilih kembali file cadangan <span className="font-semibold">.json</span> tersebut.
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={handleExportBackup}
                className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Simpan Cadangan</span>
              </button>

              <label className="py-2 px-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs flex items-center justify-center gap-1.5 cursor-pointer transition">
                <Upload className="w-3.5 h-3.5" />
                <span>Pulihkan File</span>
                <input
                  type="file"
                  onChange={handleImportBackup}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {/* Reset Demo Data */}
          <div className="pt-1">
            <button
              type="button"
              onClick={onResetData}
              className="w-full py-2 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 font-semibold text-xs flex items-center justify-center gap-1.5 transition"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset ke Data Demo Awal</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
