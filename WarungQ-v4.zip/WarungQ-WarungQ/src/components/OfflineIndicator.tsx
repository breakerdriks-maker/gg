import React, { useEffect, useRef, useState } from 'react';
import { WifiOff, Wifi } from 'lucide-react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

// Notifikasi singkat saat koneksi berubah; hilang otomatis dan bisa diketuk untuk menutup.
export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const [visible, setVisible] = useState(false);
  const firstRender = useRef(true);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    setVisible(true);
    const t = setTimeout(() => setVisible(false), 3000);
    return () => clearTimeout(t);
  }, [isOnline]);

  if (!visible) return null;

  return (
    <div
      onClick={() => setVisible(false)}
      className="fixed bottom-24 left-4 right-4 z-40 max-w-md mx-auto flex items-center gap-2 rounded-2xl bg-slate-900/95 text-white px-4 py-2.5 text-xs font-medium shadow-2xl border border-slate-700"
    >
      {isOnline ? (
        <Wifi className="w-4 h-4 text-emerald-400 shrink-0" />
      ) : (
        <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
      )}
      <span>{isOnline ? 'Kembali online' : 'Mode offline — aplikasi tetap bisa dipakai'}</span>
    </div>
  );
};
