import React, { useMemo } from 'react';
import { Printer, X } from 'lucide-react';
import { Transaction, StoreSettings } from '../types';
import { buildReceiptHtml, receiptWidthMm } from '../utils/receipt';
import { printHtml } from '../utils/nativeBridge';

interface ReceiptPreviewModalProps {
  transaction: Transaction | null;
  settings: StoreSettings;
  onClose: () => void;
}

export const ReceiptPreviewModal: React.FC<ReceiptPreviewModalProps> = ({
  transaction,
  settings,
  onClose,
}) => {
  const html = useMemo(
    () => (transaction ? buildReceiptHtml(transaction, settings) : ''),
    [transaction, settings]
  );

  if (!transaction) return null;

  const handlePrint = () => {
    printHtml(html, `Struk-${transaction.id.toString().slice(-6)}`, receiptWidthMm(settings));
  };

  return (
    <div className="fixed inset-0 z-[75] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm rounded-3xl bg-white text-slate-900 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50">
          <div>
            <h3 className="font-bold text-base">Struk Transaksi</h3>
            <p className="text-[11px] text-slate-500">
              Ketuk Cetak, lalu pilih printer atau &quot;Simpan sebagai PDF&quot;
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto bg-slate-200 p-3">
          <iframe
            title="Pratinjau struk"
            srcDoc={html}
            className="w-full bg-white rounded-lg shadow"
            style={{ height: '55vh', border: 0 }}
          />
        </div>

        <div className="p-4 border-t border-slate-100 bg-slate-50 flex gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs transition active:scale-95"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={handlePrint}
            className="flex-1 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak</span>
          </button>
        </div>
      </div>
    </div>
  );
};
