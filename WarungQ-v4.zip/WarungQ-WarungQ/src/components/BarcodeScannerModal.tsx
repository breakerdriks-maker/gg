import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Html5Qrcode, Html5QrcodeSupportedFormats } from 'html5-qrcode';
import { Camera, X, AlertCircle, RefreshCw, Zap, Upload, Check, Keyboard } from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScanSuccess: (decodedText: string) => void;
  title?: string;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onScanSuccess,
  title = 'Scan Barcode Produk',
}) => {
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [isInitializing, setIsInitializing] = useState(false);
  const [torchOn, setTorchOn] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [showManualInput, setShowManualInput] = useState(false);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isMountedRef = useRef(false);
  const isStartingRef = useRef(false);
  const readerElementId = 'html5-scanner-element';
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Play audio beep feedback on scan
  const playBeep = () => {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioContextClass) return;
      const audioCtx = new AudioContextClass();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.15);
    } catch {
      // Audio not permitted or supported, silent ignore
    }
  };

  const safelyStopScanner = useCallback(async () => {
    const scanner = scannerRef.current;
    if (!scanner) return;

    try {
      if (scanner.isScanning) {
        await scanner.stop();
      }
    } catch (err) {
      // Catch synchronous or asynchronous "Cannot stop" errors safely
      console.warn('Safe stop scanner ignored error:', err);
    }

    try {
      scanner.clear();
    } catch (err) {
      console.warn('Safe clear scanner ignored error:', err);
    }

    scannerRef.current = null;
    if (isMountedRef.current) {
      setIsScanning(false);
      setTorchOn(false);
    }
  }, []);

  const startScanner = useCallback(async () => {
    if (!isMountedRef.current || isStartingRef.current) return;

    setErrorMessage(null);
    setIsInitializing(true);
    isStartingRef.current = true;

    // Safely stop any existing scanner first
    await safelyStopScanner();

    // Check if the container element is ready in DOM
    const element = document.getElementById(readerElementId);
    if (!element || !isMountedRef.current) {
      isStartingRef.current = false;
      setIsInitializing(false);
      return;
    }
    element.innerHTML = '';

    try {
      const formatsToSupport = [
        Html5QrcodeSupportedFormats.EAN_13,
        Html5QrcodeSupportedFormats.EAN_8,
        Html5QrcodeSupportedFormats.UPC_A,
        Html5QrcodeSupportedFormats.UPC_E,
        Html5QrcodeSupportedFormats.CODE_128,
        Html5QrcodeSupportedFormats.CODE_39,
        Html5QrcodeSupportedFormats.QR_CODE,
      ];

      const html5QrCode = new Html5Qrcode(readerElementId, {
        formatsToSupport,
        verbose: false,
      });

      scannerRef.current = html5QrCode;

      const config = {
        fps: 15,
        qrbox: { width: 260, height: 180 },
        aspectRatio: 1.0,
      };

      await html5QrCode.start(
        { facingMode: 'environment' },
        config,
        (decodedText) => {
          if (!isMountedRef.current) return;
          playBeep();
          onScanSuccess(decodedText);
          onClose();
        },
        () => {
          // Frame callback - no barcode found in this frame
        }
      );

      // Check if unmounted while starting
      if (!isMountedRef.current) {
        await safelyStopScanner();
        return;
      }

      setIsScanning(true);
      setIsInitializing(false);
    } catch (err: unknown) {
      console.warn('Camera scan init notice:', err);
      if (isMountedRef.current) {
        setIsScanning(false);
        setIsInitializing(false);

        const errorStr = String(err).toLowerCase();
        if (errorStr.includes('notallowederror') || errorStr.includes('permission denied')) {
          setErrorMessage(
            'Izin kamera tidak diberikan. Silakan izinkan akses kamera di peramban atau gunakan input barcode manual di bawah.'
          );
        } else if (errorStr.includes('notfounderror') || errorStr.includes('no camera')) {
          setErrorMessage(
            'Kamera tidak ditemukan di perangkat ini. Anda dapat memasukkan kode barcode secara manual.'
          );
        } else {
          setErrorMessage(
            'Kamera belum dapat dibuka. Anda dapat mencoba lagi atau mengetik kode barcode secara manual.'
          );
        }
      }
    } finally {
      isStartingRef.current = false;
    }
  }, [onClose, onScanSuccess, safelyStopScanner]);

  useEffect(() => {
    if (!isOpen) {
      safelyStopScanner();
      setErrorMessage(null);
      setShowManualInput(false);
      setManualCode('');
      return;
    }

    isMountedRef.current = true;

    // Small delay so the modal container is mounted in DOM
    const timer = setTimeout(() => {
      startScanner();
    }, 150);

    return () => {
      isMountedRef.current = false;
      clearTimeout(timer);
      safelyStopScanner();
    };
  }, [isOpen, safelyStopScanner, startScanner]);

  const toggleTorch = async () => {
    if (!scannerRef.current || !isScanning) return;
    try {
      const applyTorch = !torchOn;
      await scannerRef.current.applyVideoConstraints({
        // @ts-expect-error advanced torch constraint
        advanced: [{ torch: applyTorch }],
      });
      setTorchOn(applyTorch);
    } catch {
      // Flashlight not supported
    }
  };

  // Scan from photo / image file as robust fallback
  const handleScanImageFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      await safelyStopScanner();

      const html5QrCode = new Html5Qrcode(readerElementId, {
        verbose: false,
      });

      const decodedText = await html5QrCode.scanFile(file, true);
      playBeep();
      onScanSuccess(decodedText);
      onClose();
    } catch {
      alert('Barcode tidak terbaca dari foto. Pastikan gambar jelas dan terang.');
      // Restart live camera
      startScanner();
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    playBeep();
    onScanSuccess(manualCode.trim());
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-150">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-indigo-400" />
            <h3 className="font-semibold text-base">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scanner Viewport */}
        <div className="p-4 flex flex-col items-center">
          <div className="relative w-full aspect-square max-h-[280px] rounded-2xl overflow-hidden bg-black flex items-center justify-center border-2 border-indigo-500/40">
            <div id={readerElementId} className="w-full h-full object-cover" />

            {/* Scanning Laser Animation */}
            {isScanning && !errorMessage && (
              <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-transparent via-red-500 to-transparent shadow-[0_0_12px_#ef4444] animate-pulse" />
            )}

            {isInitializing && !errorMessage && (
              <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 gap-2 bg-slate-900/90 z-10">
                <RefreshCw className="w-7 h-7 animate-spin text-indigo-400" />
                <span className="text-xs">Menyiapkan kamera...</span>
              </div>
            )}

            {errorMessage && (
              <div className="absolute inset-0 p-5 flex flex-col items-center justify-center text-center bg-slate-900/95 z-20">
                <AlertCircle className="w-9 h-9 text-rose-500 mb-2 shrink-0" />
                <p className="text-xs text-rose-300 font-medium mb-3 leading-relaxed">
                  {errorMessage}
                </p>
                <div className="flex flex-wrap gap-2 justify-center">
                  <button
                    onClick={startScanner}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-xs flex items-center gap-1.5 transition active:scale-95"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Coba Lagi</span>
                  </button>
                  <button
                    onClick={() => setShowManualInput(true)}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center gap-1.5 transition active:scale-95 border border-slate-700"
                  >
                    <Keyboard className="w-3.5 h-3.5" />
                    <span>Ketik Barcode</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Controls Bar */}
          <div className="flex items-center justify-between w-full mt-3 px-1 text-xs text-slate-400">
            <span className="text-[11px]">
              {isScanning ? 'Arahkan kamera ke barcode' : 'Scanner barcode'}
            </span>

            <div className="flex items-center gap-2">
              {isScanning && (
                <button
                  onClick={toggleTorch}
                  className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition ${
                    torchOn
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5" />
                  <span>{torchOn ? 'Lampu On' : 'Lampu'}</span>
                </button>
              )}

              {/* Upload image fallback */}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 text-xs transition"
                title="Pindai dari foto barcode"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Foto Barcode</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleScanImageFile}
                className="hidden"
              />
            </div>
          </div>

          {/* Manual Input Section */}
          {(showManualInput || errorMessage) && (
            <form onSubmit={handleManualSubmit} className="w-full mt-3 pt-3 border-t border-slate-800 flex gap-2">
              <input
                type="text"
                autoFocus
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Ketik nomor barcode..."
                className="flex-1 py-2 px-3 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:border-indigo-500"
              />
              <button
                type="submit"
                className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Pakai</span>
              </button>
            </form>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between gap-2">
          {!showManualInput && !errorMessage && (
            <button
              onClick={() => setShowManualInput(true)}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 px-2 py-1 rounded"
            >
              <Keyboard className="w-3.5 h-3.5" />
              <span>Input Manual</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="ml-auto py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
