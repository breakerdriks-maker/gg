import React, { useEffect, useRef, useState } from 'react';
import { Camera, RefreshCw, X } from 'lucide-react';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (dataUrl: string) => void;
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCapture,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [facing, setFacing] = useState<'environment' | 'user'>('environment');
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    let cancelled = false;
    setReady(false);
    setError(null);

    const start = async () => {
      try {
        if (!navigator.mediaDevices?.getUserMedia) {
          setError('Kamera tidak didukung di perangkat ini.');
          return;
        }
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: { ideal: facing } },
          audio: false,
        });
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }
        streamRef.current = stream;
        const video = videoRef.current;
        if (video) {
          video.srcObject = stream;
          await video.play().catch(() => {});
        }
        setReady(true);
      } catch (err) {
        const msg = String(err).toLowerCase();
        if (msg.includes('notallowed') || msg.includes('permission')) {
          setError('Izin kamera belum diberikan. Izinkan kamera di Setelan → Aplikasi → WarungQ → Izin.');
        } else {
          setError('Kamera tidak dapat dibuka.');
        }
      }
    };
    start();

    return () => {
      cancelled = true;
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    };
  }, [isOpen, facing]);

  if (!isOpen) return null;

  const handleShot = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) return;
    const max = 480;
    let w = video.videoWidth;
    let h = video.videoHeight;
    if (w > h) {
      if (w > max) {
        h = Math.round((h * max) / w);
        w = max;
      }
    } else if (h > max) {
      w = Math.round((w * max) / h);
      h = max;
    }
    const canvas = document.createElement('canvas');
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, w, h);
    let dataUrl = canvas.toDataURL('image/webp', 0.82);
    if (!dataUrl.startsWith('data:image/webp')) dataUrl = canvas.toDataURL('image/jpeg', 0.82);
    onCapture(dataUrl);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-slate-950/90 p-4">
      <div className="w-full max-w-sm rounded-3xl bg-slate-900 text-white shadow-2xl overflow-hidden border border-slate-800">
        <div className="flex items-center justify-between p-3.5 border-b border-slate-800">
          <h3 className="font-bold text-sm">Foto Produk</h3>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="relative bg-black aspect-square flex items-center justify-center">
          <video ref={videoRef} playsInline muted autoPlay className="w-full h-full object-cover" />
          {!ready && !error && (
            <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-300">
              Membuka kamera...
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center p-5 text-center text-xs text-rose-200 bg-slate-900/95">
              {error}
            </div>
          )}
        </div>

        <div className="p-4 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setFacing((f) => (f === 'environment' ? 'user' : 'environment'))}
            className="p-3 rounded-full bg-slate-800 hover:bg-slate-700 transition active:scale-95"
            title="Balik kamera"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={handleShot}
            disabled={!ready}
            className="flex-1 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 font-bold text-sm flex items-center justify-center gap-2 transition active:scale-95"
          >
            <Camera className="w-5 h-5" />
            <span>Ambil Foto</span>
          </button>
        </div>
      </div>
    </div>
  );
};
