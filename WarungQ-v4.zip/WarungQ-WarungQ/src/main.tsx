import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

import { registerSW } from 'virtual:pwa-register';

// Di dalam aplikasi Android (Capacitor) semua file sudah ada di APK,
// jadi service worker tidak diperlukan dan malah memunculkan notifikasi.
const isNativeApp = !!(window as any).Capacitor?.isNativePlatform?.();

if (isNativeApp) {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker
      .getRegistrations()
      .then((regs) => regs.forEach((r) => r.unregister()))
      .catch(() => {});
  }
} else {
  registerSW({ immediate: true });
  if ('serviceWorker' in navigator && !window.location.host.includes('localhost:3000')) {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  }
}

createRoot(document.getElementById('root')!).render(<App />);
