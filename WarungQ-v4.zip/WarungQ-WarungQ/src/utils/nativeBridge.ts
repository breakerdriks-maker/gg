// Jembatan ke fungsi native Android (hanya ada di dalam aplikasi APK).
// Di browser biasa, semuanya otomatis memakai cara web sebagai cadangan.

export interface NativeAPI {
  saveFile(name: string, mime: string, base64: string): void;
  printHtml(html: string, jobName: string, widthMm: number): void;
}

declare global {
  interface Window {
    AndroidNative?: NativeAPI;
  }
}

export type SaveResult = 'saved' | 'cancelled' | 'error';

function toBase64(data: string | Blob): Promise<string> {
  if (typeof data === 'string') {
    const bytes = new TextEncoder().encode(data);
    let bin = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      bin += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return Promise.resolve(btoa(bin));
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(data);
  });
}

/**
 * Simpan file. Di aplikasi Android akan membuka pemilih folder sistem,
 * sehingga file bisa disimpan di folder mana saja (Download, Dokumen, kartu SD, Drive, dll).
 */
export async function saveFileAs(
  filename: string,
  mime: string,
  data: string | Blob
): Promise<SaveResult> {
  if (window.AndroidNative) {
    let b64: string;
    try {
      b64 = await toBase64(data);
    } catch {
      return 'error';
    }
    return new Promise<SaveResult>((resolve) => {
      const onDone = (e: Event) => {
        window.removeEventListener('nativeSaved', onDone);
        resolve(((e as CustomEvent).detail?.status as SaveResult) || 'error');
      };
      window.addEventListener('nativeSaved', onDone);
      try {
        window.AndroidNative!.saveFile(filename, mime, b64);
      } catch {
        window.removeEventListener('nativeSaved', onDone);
        resolve('error');
      }
    });
  }

  // Cara web biasa (browser)
  try {
    const blob = typeof data === 'string' ? new Blob([data], { type: mime }) : data;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return 'saved';
  } catch {
    return 'error';
  }
}

/** Cetak dokumen HTML lewat dialog cetak Android (printer, Bluetooth, atau Simpan sebagai PDF). */
export function printHtml(html: string, jobName: string, widthMm: number): void {
  if (window.AndroidNative) {
    window.AndroidNative.printHtml(html, jobName, widthMm);
    return;
  }
  const frame = document.createElement('iframe');
  frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;';
  document.body.appendChild(frame);
  const doc = frame.contentWindow?.document;
  if (!doc) {
    document.body.removeChild(frame);
    return;
  }
  doc.open();
  doc.write(html);
  doc.close();
  setTimeout(() => {
    frame.contentWindow?.focus();
    frame.contentWindow?.print();
    setTimeout(() => {
      if (frame.parentNode) frame.parentNode.removeChild(frame);
    }, 60000);
  }, 300);
}
