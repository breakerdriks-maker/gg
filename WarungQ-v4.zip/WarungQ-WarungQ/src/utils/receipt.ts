import { Transaction, StoreSettings } from '../types';
import { formatRp } from './constants';

const esc = (s: unknown): string =>
  String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

/** Lebar kertas dalam mm (0 = kertas biasa / A4). */
export function receiptWidthMm(settings: StoreSettings): number {
  const p = settings.receiptPaper ?? '58';
  if (p === '58') return 58;
  if (p === '80') return 80;
  return 0;
}

/** Membuat dokumen HTML lengkap untuk struk (dipakai untuk pratinjau dan cetak). */
export function buildReceiptHtml(tx: Transaction, settings: StoreSettings): string {
  const w = receiptWidthMm(settings);
  const bodyWidth = w > 0 ? `${w}mm` : '80mm';
  const pageRule = w > 0 ? `@page { size: ${w}mm auto; margin: 0; }` : '@page { margin: 8mm; }';

  const items = tx.items
    .map(
      (i) => `
      <div class="item">
        <div class="name">${esc(i.name)}</div>
        <div class="row"><span>${i.qty} x ${esc(formatRp(i.price))}</span><span>${esc(
          formatRp(i.price * i.qty)
        )}</span></div>
      </div>`
    )
    .join('');

  return `<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  ${pageRule}
  * { box-sizing: border-box; }
  html, body { margin: 0; padding: 0; background: #fff; }
  body { width: ${bodyWidth}; max-width: 100%; margin: 0 auto; padding: 3mm 3mm 6mm;
    font-family: 'Courier New', Courier, monospace; font-size: 11px; line-height: 1.35; color: #000; }
  .center { text-align: center; }
  .title { font-size: 14px; font-weight: 700; letter-spacing: 1px; }
  .small { font-size: 10px; color: #333; }
  .dash { border-top: 1px dashed #000; margin: 6px 0; }
  .row { display: flex; justify-content: space-between; gap: 6px; }
  .item { margin-bottom: 4px; }
  .name { font-weight: 700; word-break: break-word; }
  .total { font-weight: 700; font-size: 12px; }
</style></head>
<body>
  <div class="center">
    <div class="title">${esc(settings.storeName.toUpperCase())}</div>
    <div class="small">${esc(settings.storeAddress)}</div>
    <div class="small">Telp: ${esc(settings.storePhone)}</div>
  </div>
  <div class="dash"></div>
  <div class="small">
    <div class="row"><span>No: #${esc(tx.id.toString().slice(-6))}</span><span>${esc(tx.date)}</span></div>
    <div class="row"><span>Kasir: Admin</span><span>Metode: ${tx.paymentMethod === 'qris' ? 'QRIS' : 'TUNAI'}</span></div>
  </div>
  <div class="dash"></div>
  ${items}
  <div class="dash"></div>
  <div class="row total"><span>TOTAL</span><span>${esc(formatRp(tx.total))}</span></div>
  <div class="row"><span>BAYAR</span><span>${esc(formatRp(tx.paid))}</span></div>
  <div class="row"><span>KEMBALI</span><span>${esc(formatRp(tx.change))}</span></div>
  <div class="dash"></div>
  <div class="center small">
    <div>${esc(settings.receiptFooter)}</div>
    <div style="margin-top:4px">*** Simpan struk ini sebagai bukti transaksi ***</div>
  </div>
</body></html>`;
}
