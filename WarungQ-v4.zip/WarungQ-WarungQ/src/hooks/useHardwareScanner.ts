import { useEffect, useRef } from 'react';

/**
 * Mendukung scanner barcode fisik (USB/OTG, USB Type-C, Bluetooth, nirkabel 2.4G)
 * yang bekerja sebagai keyboard (mode HID). Scanner mengetik kode dengan sangat cepat
 * lalu menekan Enter; ketikan manusia yang lambat diabaikan.
 */
export function useHardwareScanner(enabled: boolean, onScan: (code: string) => void) {
  const callbackRef = useRef(onScan);
  callbackRef.current = onScan;

  useEffect(() => {
    if (!enabled) return;
    let buffer = '';
    let last = 0;

    const handler = (e: KeyboardEvent) => {
      const now = Date.now();
      if (now - last > 100) buffer = '';
      last = now;

      if (e.key === 'Enter') {
        if (buffer.length >= 4) {
          e.preventDefault();
          e.stopPropagation();
          const code = buffer;
          buffer = '';
          callbackRef.current(code);
        } else {
          buffer = '';
        }
        return;
      }
      if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        buffer += e.key;
      }
    };

    window.addEventListener('keydown', handler, true);
    return () => window.removeEventListener('keydown', handler, true);
  }, [enabled]);
}
